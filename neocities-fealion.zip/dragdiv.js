document.addEventListener("DOMContentLoaded", function() {
    const draggableElements = document.querySelectorAll(".Draggable-DIV");  // Select all elements with the class "Draggable-DIV"
    
    draggableElements.forEach(function(elmnt) {
        dragElement(elmnt);  // Initialize drag on each element
    });
});

function dragElement(elmnt) {
    if (!elmnt) {
        console.error("Element not found!");
        return;
    }

    var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

    const header = elmnt.querySelector(`.${elmnt.classList[0]}-header`);  // Using class of the element to find the header
    if (header) {
        header.onmousedown = dragMouseDown;
    } else {
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
        elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}
